**穿越中文输入法**

作者： cy@baow.com

版本： 3.7

这是一种在 Vim 编辑器中使用的中文输入法，特点是简单易学，快速方便。

主页和帮助文档： <http://vim.baow.com/cyim>

Vim主页： <http://www.vim.org/scripts/script.php?script_id=4271>

安装方法：

把plugin目录下的文件复制到Vim的plugin目录下即可。

使用方法：

-   默认切换开关： A-i 或 C-\\
-   详见说明文档

Emacs版本： <https://github.com/cy2081/cyim-emacs>
